"""Causal Sparsemax replacement matching GPTMini.Convex.Attention.

The reference GPTMini source stays unchanged. This subclass only replaces
the probability map in CausalMHA.forward; the remaining operations match it.
"""

import torch
from torch import nn
from torch.nn import functional as F

from experiments.gpt_mini import CausalMHA, GPTMini, apply_rope


class SparsemaxFunction(torch.autograd.Function):
    @staticmethod
    def forward(ctx, scores):
        maximum = scores.amax(dim=-1, keepdim=True)
        if not bool(maximum.isfinite().all()):
            if bool((maximum.isnan() | torch.isposinf(maximum)).any()):
                raise FloatingPointError("Nonfinite Sparsemax attention scores")
            raise ValueError("Sparsemax requires a nonempty finite allowed row")
        # Simplex projection is translation invariant. Center first to avoid
        # losing unit probability mass when a float32 row has a large offset.
        scores = scores - maximum
        ordered = scores.sort(dim=-1, descending=True).values
        cumulative = ordered.cumsum(dim=-1)
        ranks = torch.arange(1, scores.size(-1) + 1, device=scores.device, dtype=scores.dtype)
        support_size = (1 + ranks * ordered > cumulative).sum(dim=-1, keepdim=True)
        threshold = (cumulative.gather(-1, support_size - 1) - 1) / support_size
        probabilities = (scores - threshold).clamp_min(0)
        active = probabilities > 0
        ctx.save_for_backward(active)
        return probabilities

    @staticmethod
    def backward(ctx, output_gradient):
        (active,) = ctx.saved_tensors
        count = active.sum(dim=-1, keepdim=True)
        mean = (output_gradient * active).sum(dim=-1, keepdim=True) / count
        return active * (output_gradient - mean)


def sparsemax(scores):
    return SparsemaxFunction.apply(scores)


class SparsemaxMHA(CausalMHA):
    def forward(self, x, cos, sin):
        batch, length, width = x.shape
        q, k, v = self.qkv(x).chunk(3, dim=-1)
        q = q.view(batch, length, self.n_heads, self.head_dim).transpose(1, 2)
        k = k.view(batch, length, self.n_heads, self.head_dim).transpose(1, 2)
        v = v.view(batch, length, self.n_heads, self.head_dim).transpose(1, 2)
        q = apply_rope(F.normalize(q, dim=-1, eps=1e-6), cos, sin)
        k = apply_rope(F.normalize(k, dim=-1, eps=1e-6), cos, sin)
        alpha = self.log_alpha.exp().view(1, self.n_heads, 1, 1)
        scores = (q @ k.transpose(-2, -1)) * alpha
        forbidden = torch.ones((length, length), device=x.device, dtype=torch.bool).triu(1)
        probabilities = sparsemax(scores.masked_fill(forbidden, float("-inf")))
        y = probabilities @ v
        v_hat = F.normalize(v, dim=-1, eps=1e-6)
        z = y - (y * v_hat).sum(dim=-1, keepdim=True) * v_hat
        return self.proj(z.transpose(1, 2).contiguous().view(batch, length, width))


def make_model(config, attention, seed, device="cpu"):
    if attention not in {"softmax", "sparsemax"}:
        raise ValueError(attention)
    # Allocate the identical reference parameters for both attention types.
    torch.manual_seed(seed)
    model = GPTMini(config)
    if attention == "sparsemax":
        for block in model.blocks:
            # The subclass has the same parameter structure; no reinitialization.
            block.attn.__class__ = SparsemaxMHA
    with torch.no_grad():
        for p in model.parameters():
            if p.ndim == 2:
                nn.init.normal_(p, mean=0.0, std=0.02)
    return model.to(device)
